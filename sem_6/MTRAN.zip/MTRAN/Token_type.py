class Token_type:
    def __init__(self, name, regex):
        self.name = name
        self.regex = regex

