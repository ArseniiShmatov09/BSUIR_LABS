class Token:
    def __init__(self, name, type, pos):
        self.name = name
        self.type = type
        self.pos = pos

